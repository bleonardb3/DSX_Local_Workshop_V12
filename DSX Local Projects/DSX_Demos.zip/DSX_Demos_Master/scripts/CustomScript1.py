from __future__ import print_function
import sys

def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)

def add_handler(num1, num2, num3):
    print('STDOUT in add_handler')
    dict = {}
    dict['sum'] = num1 + num2 + num3
    sys.stderr.write('Another STDERR in add_handler')
    return dict

def add(obj):
    print('A sample STDOUT message')
    a = obj['a']
    b = obj['b']
    c = obj['c']
    eprint('Sample STDERR message')

    return add_handler(a, b, c)

def init():
    # Do nothing for now
    pass